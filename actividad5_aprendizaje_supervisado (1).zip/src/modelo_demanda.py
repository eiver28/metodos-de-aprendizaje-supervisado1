"""Modelo supervisado para clasificar demanda alta en transporte masivo."""
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.tree import DecisionTreeClassifier, export_text

TARGET = "demanda_alta"
CATEGORICAL = ["dia_semana", "hora", "estacion", "clima", "evento"]
NUMERIC = ["demanda_pasajeros", "ocupacion_promedio", "incidentes", "tiempo_espera_min"]


def cargar_datos(path: str | Path) -> pd.DataFrame:
    datos = pd.read_csv(path)
    columnas = set(CATEGORICAL + NUMERIC + [TARGET])
    faltantes = columnas.difference(datos.columns)
    if faltantes:
        raise ValueError(f"Faltan columnas requeridas: {sorted(faltantes)}")
    if datos[TARGET].isna().any():
        raise ValueError("La variable objetivo contiene valores vacíos")
    return datos


def construir_modelo() -> Pipeline:
    preprocesador = ColumnTransformer(
        transformers=[
            ("categoricas", OneHotEncoder(handle_unknown="ignore"), CATEGORICAL),
            ("numericas", "passthrough", NUMERIC),
        ]
    )
    arbol = DecisionTreeClassifier(max_depth=4, random_state=42, class_weight="balanced")
    return Pipeline([("preprocesamiento", preprocesador), ("clasificador", arbol)])


def entrenar(datos: pd.DataFrame) -> tuple[Pipeline, pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
    requeridas = set(CATEGORICAL + NUMERIC + [TARGET])
    faltantes = requeridas.difference(datos.columns)
    if faltantes:
        raise ValueError(f"Faltan columnas requeridas: {sorted(faltantes)}")
    X = datos[CATEGORICAL + NUMERIC]
    y = datos[TARGET]
    X_ent, X_prueba, y_ent, y_prueba = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    modelo = construir_modelo()
    modelo.fit(X_ent, y_ent)
    return modelo, X_ent, X_prueba, y_ent, y_prueba


def evaluar(modelo: Pipeline, X_prueba: pd.DataFrame, y_prueba: pd.Series) -> dict[str, Any]:
    predicciones = modelo.predict(X_prueba)
    return {
        "accuracy": accuracy_score(y_prueba, predicciones),
        "confusion_matrix": confusion_matrix(y_prueba, predicciones, labels=["no", "si"]),
        "report": classification_report(y_prueba, predicciones, zero_division=0),
        "predicciones": predicciones,
    }


def ejecutar(path: str, guardar_modelo: str | None = None) -> None:
    datos = cargar_datos(path)
    modelo, _, X_prueba, _, y_prueba = entrenar(datos)
    resultados = evaluar(modelo, X_prueba, y_prueba)
    print(f"Registros utilizados: {len(datos)}")
    print(f"Exactitud: {resultados['accuracy']:.3f}")
    print("Matriz de confusión [no, si]:")
    print(resultados["confusion_matrix"])
    print("Reporte de clasificación:")
    print(resultados["report"])
    print("\nReglas aproximadas del árbol:")
    nombres = modelo.named_steps["preprocesamiento"].get_feature_names_out()
    arbol = modelo.named_steps["clasificador"]
    print(export_text(arbol, feature_names=list(nombres), max_depth=2))
    if guardar_modelo:
        joblib.dump(modelo, guardar_modelo)
        print(f"Modelo guardado en: {guardar_modelo}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--datos", default="data/transporte_masivo_muestra.csv")
    parser.add_argument("--guardar-modelo", default=None)
    args = parser.parse_args()
    ejecutar(args.datos, args.guardar_modelo)
