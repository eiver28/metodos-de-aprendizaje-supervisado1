import unittest
from pathlib import Path

from src.modelo_demanda import cargar_datos, entrenar, evaluar


DATA = Path(__file__).parents[1] / "data" / "transporte_masivo_muestra.csv"


class TestModeloDemanda(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.datos = cargar_datos(DATA)
        cls.modelo, _, cls.X_prueba, _, cls.y_prueba = entrenar(cls.datos)

    def test_dataset_tiene_registros_y_columnas(self):
        self.assertEqual(len(self.datos), 45)
        self.assertIn("demanda_alta", self.datos.columns)

    def test_entrenamiento_produce_predicciones(self):
        resultados = evaluar(self.modelo, self.X_prueba, self.y_prueba)
        self.assertGreaterEqual(resultados["accuracy"], 0.70)
        self.assertEqual(len(resultados["predicciones"]), len(self.y_prueba))

    def test_datos_incompletos_generan_error(self):
        datos = self.datos.drop(columns=["clima"])
        with self.assertRaises(ValueError):
            from src.modelo_demanda import entrenar
            entrenar(datos)


if __name__ == "__main__":
    unittest.main()
