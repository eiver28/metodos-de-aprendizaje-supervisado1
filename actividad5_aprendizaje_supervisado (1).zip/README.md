# Actividad 3 — Métodos de aprendizaje supervisado

## Proyecto

**Clasificación de demanda alta en estaciones de transporte masivo mediante un árbol de decisión.**

El programa recibe datos de operación de una estación y predice si la demanda será alta (`si`) o no alta (`no`). El modelo utiliza variables como día, hora, estación, clima, evento, pasajeros, ocupación, incidentes y tiempo de espera.

> El archivo incluido es una **muestra académica construida por el equipo**, porque la actividad permite elaborar un dataset cuando no se dispone de una fuente operativa completa. No representa datos oficiales ni debe presentarse como información real de una empresa de transporte.

## Requisitos

- Python 3.10 o posterior.
- Git.

## Instalación

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
```

## Ejecución del modelo

Desde la carpeta principal:

```bash
python src/modelo_demanda.py --datos data/transporte_masivo_muestra.csv
```

Para guardar el modelo entrenado:

```bash
python src/modelo_demanda.py --datos data/transporte_masivo_muestra.csv --guardar-modelo modelo_demanda.joblib
```

## Ejecución de pruebas

```bash
python -m unittest discover -s tests -v
```

## Lógica del proyecto

La variable objetivo es `demanda_alta`. Se considera una tarea de aprendizaje supervisado porque cada registro tiene características de entrada y una etiqueta conocida. El flujo es:

1. Leer el archivo CSV.
2. Separar las variables predictoras de la etiqueta.
3. Codificar las variables categóricas con one-hot encoding.
4. Dividir los datos en entrenamiento y prueba.
5. Entrenar un árbol de decisión.
6. Calcular exactitud, matriz de confusión y reporte de clasificación.
7. Interpretar algunas reglas aproximadas del árbol.

## Estructura

```text
actividad5_aprendizaje_supervisado/
├── data/transporte_masivo_muestra.csv
├── src/modelo_demanda.py
├── tests/test_modelo_demanda.py
├── docs/descripcion_datos.md
├── docs/pruebas.md
├── docs/mapa_conceptual.md
├── docs/guion_video.md
├── docs/entrega.md
├── requirements.txt
└── README.md
```

## Trabajo colaborativo

Cada integrante debe hacer un aporte real y registrarlo con su propia cuenta Git. Se recomienda repartir así:

| Integrante | Aporte |
|---|---|
| 1 | Definición y documentación del dataset. |
| 2 | Preprocesamiento y entrenamiento del modelo. |
| 3 | Pruebas y evaluación de resultados. |
| 4 | Mapa conceptual, informe y video. |

El tutor debe agregarse como colaborador desde la configuración del repositorio.
