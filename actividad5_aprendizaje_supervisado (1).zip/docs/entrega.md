# Documento de entrega — Actividad 3

**Curso:** [Nombre del curso]  
**Docente:** [Nombre del tutor]  
**Grupo:** [Número]  
**Integrantes:** [Nombres completos de máximo cuatro estudiantes]  
**Fecha:** [Fecha]

## Proyecto

**Clasificación de demanda alta en estaciones de transporte masivo mediante un árbol de decisión.**

El proyecto utiliza una muestra de datos académica y un modelo de aprendizaje supervisado implementado en Python. El programa recibe variables operativas y predice si la demanda de pasajeros es alta.

## Enlaces

- **Repositorio Git/GitLab:** [Pegar enlace real]
- **Video:** [Pegar enlace real]
- **Mapa conceptual:** disponible en `docs/mapa_conceptual.md` y [pegar enlace público si se solicita]
- **PDF de descripción de datos:** [Pegar enlace o nombre del archivo]
- **PDF de pruebas:** [Pegar enlace o nombre del archivo]

## Archivos del repositorio

- `data/transporte_masivo_muestra.csv`: fuente de datos de la muestra.
- `src/modelo_demanda.py`: código Python del modelo.
- `docs/descripcion_datos.md`: descripción, variables, fuente y limitaciones.
- `docs/pruebas.md`: pruebas realizadas y resultados.
- `docs/mapa_conceptual.md`: mapa conceptual.
- `docs/guion_video.md`: guía de presentación.
- `README.md`: instalación y ejecución.

## Aportes

| Integrante | Aporte real | Commit o enlace |
|---|---|---|
| [Nombre 1] | [Completar] | [Completar] |
| [Nombre 2] | [Completar] | [Completar] |
| [Nombre 3] | [Completar] | [Completar] |
| [Nombre 4] | [Completar] | [Completar] |

> Completen los campos entre corchetes, agreguen al tutor como colaborador y sustituyan los resultados de ejemplo por la salida real obtenida por el equipo.
