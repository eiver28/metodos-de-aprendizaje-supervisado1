# Descripción de los datos

## 1. Contexto

El proyecto busca anticipar si la demanda de pasajeros en una estación de transporte masivo será alta. Esta predicción puede apoyar decisiones como refuerzo de frecuencias, distribución de personal y preparación de información al usuario.

La actividad permite construir una muestra cuando no existe un archivo operativo disponible. Por esa razón, `data/transporte_masivo_muestra.csv` es un dataset académico elaborado con valores plausibles. Es una muestra de trabajo y no una fuente oficial.

## 2. Unidad de observación

Cada fila representa una observación de una estación durante una franja horaria de un día determinado. El archivo tiene 45 registros y 10 columnas.

| Columna | Tipo | Descripción |
|---|---|---|
| `dia_semana` | Categórica | Día de la semana. |
| `hora` | Categórica | Franja horaria observada. |
| `estacion` | Categórica | Estación del sistema. |
| `clima` | Categórica | Condición general: normal o lluvia. |
| `evento` | Categórica | Indica si existe un evento especial. |
| `demanda_pasajeros` | Numérica | Número estimado de pasajeros en la franja. |
| `ocupacion_promedio` | Numérica | Ocupación promedio expresada como proporción entre 0 y 1. |
| `incidentes` | Numérica | Número de incidentes reportados en la franja. |
| `tiempo_espera_min` | Numérica | Tiempo medio de espera en minutos. |
| `demanda_alta` | Objetivo | Etiqueta que el modelo aprende: `si` o `no`. |

## 3. Fuentes consideradas

Se consideraron tres posibilidades: datos abiertos de movilidad, registros internos del operador y una muestra construida. Como para esta entrega no se cuenta con un archivo autorizado y completo del operador, se utiliza la tercera opción. La fuente inmediata del modelo es el CSV incluido en el repositorio.

En un proyecto aplicado, se debería reemplazar la muestra por datos abiertos verificables o por datos anonimizados suministrados por el operador. También habría que documentar fecha de descarga, licencia, cobertura geográfica y método de limpieza.

## 4. Preparación

Las variables de texto se convierten con `OneHotEncoder`. Las variables numéricas se conservan como números. El conjunto se divide con `random_state=42` para que la práctica sea reproducible. Se utiliza un árbol de decisión con profundidad máxima de cuatro niveles para mantener la explicación comprensible y reducir el riesgo de memorizar la muestra.

## 5. Limitaciones

La muestra no representa toda la operación del sistema. Los registros no incluyen festivos, vacaciones, transbordos, capacidad de cada vehículo ni información en tiempo real. Por ello, la exactitud obtenida solo describe este experimento y no debe interpretarse como una garantía para la operación real.
