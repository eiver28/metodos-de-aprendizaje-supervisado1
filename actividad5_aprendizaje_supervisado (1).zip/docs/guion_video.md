# Guion del video — máximo 10 minutos

## Distribución sugerida

| Tiempo | Participante | Contenido |
|---|---|---|
| 0:00–0:45 | Integrante 1 | Presentación del equipo, problema y objetivo. |
| 0:45–2:00 | Integrante 1 | Explicación de la fuente de datos y de las columnas del CSV. |
| 2:00–3:30 | Integrante 2 | Explicación del código, carga, separación de variables y preprocesamiento. |
| 3:30–5:00 | Integrante 2 | Árbol de decisión, entrenamiento y división de entrenamiento/prueba. |
| 5:00–6:30 | Integrante 3 | Ejecución del programa y explicación de exactitud y matriz de confusión. |
| 6:30–8:00 | Integrante 3 | Ejecución de pruebas automáticas y lectura del reporte. |
| 8:00–9:15 | Integrante 4 | Mostrar el mapa conceptual y relacionarlo con el proyecto. |
| 9:15–10:00 | Todos | Conclusiones, limitaciones y despedida. |

## Texto orientador

“En esta actividad construimos un modelo de aprendizaje supervisado para clasificar si la demanda de pasajeros de una estación es alta. Cada registro tiene variables de entrada y una etiqueta conocida, por eso el modelo puede aprender de ejemplos anteriores.”

“El dataset es una muestra académica elaborada para el ejercicio, porque no contamos con un archivo operativo autorizado. Las variables incluyen día, hora, estación, clima, evento, número de pasajeros, ocupación, incidentes y tiempo de espera. La variable que queremos predecir es `demanda_alta`.”

“Elegimos un árbol de decisión porque permite explicar las condiciones que llevan a una predicción. Las variables categóricas se transforman con one-hot encoding y después el modelo se entrena con una parte de los registros. La otra parte se reserva para evaluar su comportamiento con datos que no utilizó durante el entrenamiento.”

“Ahora ejecutamos el archivo con el comando `python src/modelo_demanda.py --datos data/transporte_masivo_muestra.csv`. El programa muestra la exactitud, la matriz de confusión y el reporte de clasificación. La exactitud indica la proporción total de predicciones correctas, mientras que la matriz permite separar aciertos y errores por clase.”

“Finalmente ejecutamos las pruebas automáticas. Estas comprueban que el CSV se cargue, que el modelo produzca predicciones y que el programa informe un error cuando falta una columna necesaria.”

## Cierre

“Concluimos que el aprendizaje supervisado puede apoyar la planeación del transporte al anticipar franjas de demanda alta. El resultado es solamente un prototipo, porque la muestra es académica y no incluye datos en tiempo real. Para llevarlo a producción se necesitarían datos oficiales, más registros, validación temporal y una revisión con expertos del operador.”
