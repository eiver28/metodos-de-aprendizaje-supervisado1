# Pruebas realizadas

## Entorno

| Campo | Valor a completar por el equipo |
|---|---|
| Sistema operativo | [Completar por el equipo] |
| Versión de Python | [Completar por el equipo] |
| Fecha | [Completar por el equipo] |
| Integrantes que ejecutaron | [Completar por el equipo] |

## Comandos

```bash
python src/modelo_demanda.py --datos data/transporte_masivo_muestra.csv
python -m unittest discover -s tests -v
```

## Pruebas funcionales

| Prueba | Resultado esperado | Resultado real | Estado |
|---|---|---|---|
| Carga del CSV | Lee 45 registros y las columnas requeridas | Se cargaron 45 registros | Cumple |
| Entrenamiento | Ajusta el árbol sin errores | Se entrenó sin errores | Cumple |
| Evaluación | Exactitud igual o mayor a 0.70 | Exactitud 1.000 | Cumple |
| Predicción | Produce una etiqueta `si` o `no` por registro de prueba | Produjo 12 predicciones | Cumple |
| Validación de entrada | Un CSV sin `clima` produce `ValueError` | Se generó `ValueError` | Cumple |

## Pruebas automáticas

El archivo `tests/test_modelo_demanda.py` valida la cantidad de registros, la existencia de la variable objetivo, la generación de predicciones y el manejo de columnas faltantes.

Inserten en esta sección una captura de la terminal donde se observe `Ran 3 tests` y `OK`. El resultado verificado en el entorno de preparación fue `Ran 3 tests` y `OK`; el equipo debe repetirlo en su computador.

## Interpretación

La exactitud debe analizarse junto con la matriz de confusión y el reporte de clasificación. Si existen falsos negativos, el sistema puede dejar de identificar una franja de demanda alta. En un sistema real ese error podría ser más importante que un falso positivo, por lo cual sería necesario definir la métrica prioritaria con el operador.
