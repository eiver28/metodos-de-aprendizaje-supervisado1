# Mapa conceptual — aprendizaje supervisado aplicado al transporte

```mermaid
flowchart TD
    A[Problema de transporte masivo] --> B[Datos etiquetados]
    B --> C[Variables predictoras]
    B --> D[Variable objetivo: demanda alta]
    C --> E[Preprocesamiento]
    E --> F[Codificación de variables categóricas]
    E --> G[Separación entrenamiento/prueba]
    F --> H[Árbol de decisión]
    G --> H
    H --> I[Predicción: si / no]
    I --> J[Evaluación]
    J --> K[Exactitud]
    J --> L[Matriz de confusión]
    J --> M[Reporte de clasificación]
    M --> N[Decisión operativa]
    N --> O[Refuerzo de frecuencias y personal]
```

**Idea central:** el aprendizaje supervisado aprende una relación entre variables de entrada y una etiqueta conocida. En este proyecto, el árbol de decisión aprende patrones de demanda alta a partir de condiciones de operación de una estación.
